const api_startupRegister = "/register/startup";
const api_addGraphData =
  "/adddata/timelinegraph/graphevent";
const api_startupDetailsEdit =
  "/editdata/startup/basicdetails";
const api_founderDetailsEdit =
  "/editdata/startup/teammember";
const api_addGraphDataType = "/adddata/timelinegraph/type";

// const api_startupRegister = "http://52.66.154.242:3000/register/startup";
// const api_addGraphData =
//   "http://52.66.154.242:3000/adddata/timelinegraph/graphevent";
// const api_startupDetailsEdit =
//   "http://52.66.154.242:3000/editdata/startup/basicdetails";
// const api_founderDetailsEdit =
//   "http://52.66.154.242:3000/editdata/startup/teammember";
// const api_addGraphDataType = "http://52.66.154.242:3000/adddata/timelinegraph/type";
