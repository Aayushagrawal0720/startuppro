// module.exports={
//     database:'  database:'mongodb+srv://Ayush-startuppro:<Ayush-startuppro>@cluster0.bgawn.mongodb.net/?retryWrites=true&w=majority''
//     // database:'mongodb://13.127.125.54:27017/startuppro'
// }